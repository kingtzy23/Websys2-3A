<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
class StudentController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->search;

    $students = Student::when($search, function ($query) use ($search) {
        $query->where('name', 'like', "%$search%");
    })->get();

    foreach ($students as $student) {
        $student->qr = QrCode::size(80)->generate(route('students.show', $student->id));
    }

    return view('students.index', compact('students','search'));
    }

    public function create()
    {
        return view('students.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'student_no'=>'required',
            'name'=>'required',
            'course'=>'required',
            'year_level'=>'required',
            'email'=>'required|email|unique:students',
            'photo'=>'required|image'
        ]);

        // Upload photo
        $photoPath = $request->file('photo')->store('students','public');

        Student::create([
            'student_no'=>$request->student_no,
            'name'=>$request->name,
            'course'=>$request->course,
            'year_level'=>$request->year_level,
            'email'=>$request->email,
            'photo'=>$photoPath,
        ]);

        return redirect()->route('students.index')->with('success','Student Added');
    }

    public function show(Student $student)
    {
        $qr = QrCode::size(200)->generate(json_encode($student));
        return view('students.show', compact('student','qr'));
    }

    public function edit(Student $student)
    {
        return view('students.edit', compact('student'));
    }

    public function update(Request $request, Student $student)
    {
        $request->validate([
            'student_no'=>'required',
            'name'=>'required',
            'course'=>'required',
            'year_level'=>'required',
            'email'=>"required|email|unique:students,email,$student->id",
        ]);

        if($request->hasFile('photo')){
            $photoPath = $request->file('photo')->store('students','public');
            $student->photo = $photoPath;
        }

        $student->update($request->all());

        return redirect()->route('students.index')->with('success','Updated');
    }

    public function destroy(Student $student)
    {
        $student->delete();
        return redirect()->route('students.index')->with('success','Deleted');
    }
}