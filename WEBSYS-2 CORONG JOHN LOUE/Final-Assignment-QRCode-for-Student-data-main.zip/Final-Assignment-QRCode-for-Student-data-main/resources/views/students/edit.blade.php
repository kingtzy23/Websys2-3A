@extends('layouts.app')

@section('content')

<style>
    body {
        background: linear-gradient(135deg, #0d6efd, #0a58ca);
        min-height: 100vh;
    }

    .page-title {
        color: white;
        font-weight: 700;
        text-align: center;
        margin-bottom: 25px;
    }

    .card-custom {
        background: #fff;
        border-radius: 18px;
        box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
        padding: 35px;
        border: none;
    }

    .form-label {
        font-weight: 600;
        font-size: 0.9rem;
        color: #333;
    }

    .form-control {
        border-radius: 12px;
        padding: 12px 14px;
        border: 1px solid #dee2e6;
        transition: 0.2s;
    }

    .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 0.2rem rgba(13,110,253,.15);
    }

    .btn {
        border-radius: 12px;
        padding: 12px;
        font-weight: 600;
    }

    .btn-primary {
        background: #0d6efd;
    }

    .btn-outline-secondary {
        border-radius: 12px;
    }

    .container-box {
        max-width: 700px;
    }

    .subtitle {
        text-align: center;
        color: rgba(255,255,255,0.8);
        margin-bottom: 10px;
    }
</style>

<div class="container mt-5 container-box">

    <div class="subtitle">Student Management System</div>
    <h2 class="page-title">✏️ Edit Student</h2>

    <div class="card-custom">

        <form action="{{ route('students.update',$student->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label">Student Number</label>
                <input type="text" name="student_no" class="form-control"
                    value="{{ $student->student_no }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control"
                    value="{{ $student->name }}" required>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Course</label>
                    <input type="text" name="course" class="form-control"
                        value="{{ $student->course }}" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Year Level</label>
                    <input type="text" name="year_level" class="form-control"
                        value="{{ $student->year_level }}" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control"
                    value="{{ $student->email }}" required>
            </div>

            <div class="mb-4">
                <label class="form-label">Change Photo</label>
                <input type="file" name="photo" class="form-control">
            </div>

            <div class="row g-2">
                <div class="col-md-6">
                    <button class="btn btn-primary w-100">
                        Update Student
                    </button>
                </div>
                <div class="col-md-6">
                    <a href="{{ route('students.index') }}" class="btn btn-outline-secondary w-100">
                        Cancel
                    </a>
                </div>
            </div>

        </form>

    </div>
</div>

@endsection