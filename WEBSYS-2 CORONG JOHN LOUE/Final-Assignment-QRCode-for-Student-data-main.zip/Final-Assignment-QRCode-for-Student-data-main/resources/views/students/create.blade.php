@extends('layouts.app')

@section('content')

<div class="container py-4">

    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">➕ Add New Student</h5>
                </div>

                <div class="card-body">

                    <form method="POST" enctype="multipart/form-data" action="{{ route('students.store') }}">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label">Student Number</label>
                            <input type="text" name="student_no" class="form-control" placeholder="Enter student number">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter full name">
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Course</label>
                                <input type="text" name="course" class="form-control" placeholder="e.g. BSIT">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Year Level</label>
                                <input type="text" name="year_level" class="form-control" placeholder="e.g. 1st Year">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="example@gmail.com">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Student Photo</label>
                            <input type="file" name="photo" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-success w-100 py-2">
                            Save Student
                        </button>

                    </form>

                </div>
            </div>

        </div>
    </div>

</div>

@endsection