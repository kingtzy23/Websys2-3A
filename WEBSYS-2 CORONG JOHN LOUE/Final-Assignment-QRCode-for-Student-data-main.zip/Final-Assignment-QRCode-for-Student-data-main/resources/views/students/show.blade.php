@extends('layouts.app')
@section('content')
 <h2 class="page-title" style="color: blue;"><center>View Details</center></h2>
<div class="text-center">
    <img src="{{ asset('storage/'.$student->photo) }}" width="140" class="rounded-circle mb-3">

    <h2>{{ $student->name }}</h2>
    <p><b>Course:</b> {{ $student->course }}</p>
    <p><b>Year:</b> {{ $student->year_level }}</p>
    <p><b>Email:</b> {{ $student->email }}</p>

    <hr>
    <h4 class="mb-3">📱 Student QR Code</h4>
    <div class="p-3 bg-light d-inline-block rounded shadow">
        {!! $qr !!}
    </div>

    <br><br>
    <a href="{{ route('students.index') }}" class="btn btn-secondary">Back</a>
</div>

@endsection