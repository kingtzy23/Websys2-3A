@extends('layouts.app')
@section('content')

<div class="container">

    <h2 class="mb-4 text-primary">🎓 Student List</h2>

    {{-- SUCCESS ALERT --}}
    @if(session('success'))
    <script>
        document.addEventListener("DOMContentLoaded", function(){
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: "{{ session('success') }}",
                timer: 2000,
                showConfirmButton: false
            });
        });
    </script>
    @endif

    <form method="GET" class="mb-4">
        <div class="input-group shadow-sm">
            <input name="search" value="{{ $search }}" class="form-control" placeholder="🔍 Search student...">
            <button class="btn btn-primary">Search</button>
            <a href="{{ route('students.create') }}" class="btn btn-success">+ Add Student</a>
        </div>
    </form>

    <div class="card shadow-lg">
        <div class="card-body">

            <table class="table table-hover text-center align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Year</th>
                        <th>QR Code</th>
                        <th width="220">Actions</th>
                    </tr>
                </thead>

                <tbody>
                @foreach($students as $student)
                <tr>
                    <td>
                        <img src="{{ asset('storage/'.$student->photo) }}" width="60" class="rounded-circle shadow">
                    </td>

                    <td><b>{{ $student->name }}</b></td>
                    <td>{{ $student->course }}</td>
                    <td>{{ $student->year_level }}</td>

                    <td>{!! $student->qr !!}</td>

                    <td>
                        <a href="{{ route('students.show',$student->id) }}" class="btn btn-info btn-sm">View</a>
                        <a href="{{ route('students.edit',$student->id) }}" class="btn btn-warning btn-sm">Edit</a>

                        <form action="{{ route('students.destroy',$student->id) }}" method="POST" style="display:inline">
                            @csrf 
                            @method('DELETE')
                            <button type="button" class="btn btn-danger btn-sm deleteBtn">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                </tbody>

            </table>

        </div>
    </div>
</div>

@endsection


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll('.deleteBtn').forEach(button => {
        button.addEventListener('click', function () {
            let form = this.closest('form');

            Swal.fire({
                title: 'Are you sure?',
                text: "This student will be deleted!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            })
        });
    });
});
</script>