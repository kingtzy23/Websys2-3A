<!DOCTYPE html>
<html>
<head>
    <title>Student QR System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg,#0d6efd,#0a58ca);
            min-height:100vh;
        }
        .main-card{
            background:white;
            border-radius:15px;
            padding:30px;
            box-shadow:0 10px 30px rgba(0,0,0,.2);
        }
        .title{
            color:white;
            font-weight:bold;
            text-align:center;
            margin:30px 0;
        }
        .btn-primary{ background:#0d6efd; border:none; }
        .btn-success{ background:#198754; border:none; }
        .btn-warning{ background:#ffc107; border:none; }
        .btn-danger{ background:#dc3545; border:none; }
        table th{ background:#0d6efd; color:white; }
    </style>
</head>

<body>
    <h1 class="title">🎓 Student QR Code System</h1>

    <div class="container">
        <div class="main-card">
            @yield('content')
        </div>
    </div>
</body>
</html>