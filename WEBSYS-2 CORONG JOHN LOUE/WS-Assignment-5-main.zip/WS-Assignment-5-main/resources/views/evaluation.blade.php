<!DOCTYPE html>
<html>
<head>
    <title>Student Evaluation</title>
    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 40px;
        }
        .box {
            background: white;
            padding: 20px;
            width: 400px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }
        input, button {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        .result {
            background: #e9ffe9;
            padding: 15px;
            margin-top: 15px;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Student Evaluation</h2>

    <form method="post" action="/evaluation">
        @csrf
        <input type="text" name="name" placeholder="Student Name" required>
        <input type="number" name="prelim" placeholder="Prelim Grade" required>
        <input type="number" name="midterm" placeholder="Midterm Grade" required>
        <input type="number" name="final" placeholder="Final Grade" required>
        <button type="submit">Evaluate</button>
    </form>

    @if(isset($name))
        @php
            $average = ($prelim + $midterm + $final) / 3;
        @endphp

        {{-- LETTER GRADE --}}
        @if($average >= 90 && $average <= 100)
            @php $letter = "A"; @endphp
        @elseif($average >= 80)
            @php $letter = "B"; @endphp
        @elseif($average >= 70)
            @php $letter = "C"; @endphp
        @elseif($average >= 60)
            @php $letter = "D"; @endphp
        @else
            @php $letter = "F"; @endphp
        @endif

        {{-- REMARKS --}}
        @if($average >= 75)
            @php $remarks = "Passed"; @endphp
        @else
            @php $remarks = "Failed"; @endphp
        @endif

        {{-- AWARD --}}
        @if($average >= 98 && $average <= 100)
            @php $award = "With Highest Honors"; @endphp
        @elseif($average >= 95)
            @php $award = "With High Honors"; @endphp
        @elseif($average >= 90)
            @php $award = "With Honors"; @endphp
        @else
            @php $award = "No Award"; @endphp
        @endif

        <div class="result">
            <p><strong>Name:</strong> {{ $name }}</p>
            <p><strong>Average:</strong> {{ number_format($average, 2) }}</p>
            <p><strong>Letter Grade:</strong> {{ $letter }}</p>
            <p><strong>Remarks:</strong> {{ $remarks }}</p>
            <p><strong>Award:</strong> {{ $award }}</p>
        </div>
    @endif

</div>

</body>
</html>
