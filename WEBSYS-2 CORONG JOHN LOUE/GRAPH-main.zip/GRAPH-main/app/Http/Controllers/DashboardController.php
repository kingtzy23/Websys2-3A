<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $salesData = Sale::select(
                DB::raw('SUM(amount) as total'),
                DB::raw('MONTH(sale_date) as month_number'),
                DB::raw('MONTHNAME(sale_date) as month')
            )
            ->groupBy('month_number', 'month')
            ->orderBy('month_number')
            ->get();

        $labels = $salesData->pluck('month');
        $data = $salesData->pluck('total');

        return view('dashboard', compact('labels', 'data'));
    }
}