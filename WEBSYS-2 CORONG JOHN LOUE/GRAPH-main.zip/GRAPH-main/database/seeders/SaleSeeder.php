<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Sale;

class SaleSeeder extends Seeder
{
    public function run(): void
    {
        Sale::insert([
            ['amount' => 1000, 'sale_date' => '2026-01-10'],
            ['amount' => 2000, 'sale_date' => '2026-02-10'],
            ['amount' => 1500, 'sale_date' => '2026-03-10'],
            ['amount' => 3000, 'sale_date' => '2026-04-10'],
        ]);
    }
}
