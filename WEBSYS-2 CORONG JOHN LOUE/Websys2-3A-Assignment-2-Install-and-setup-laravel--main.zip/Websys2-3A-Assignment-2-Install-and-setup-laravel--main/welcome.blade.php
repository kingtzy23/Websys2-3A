<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#f3f4f6;
">

    <div style="text-align:center;">
        <h1 style="
            font-size:40px;
            font-weight:bold;
            color:#2563eb;
        ">
            JOHN LOUIE CORONG
        </h1>

        <p style="
            margin-top:8px;
            font-size:14px;
            color:#6b7280;
        ">
            Laravel {{ app()->version() }} | PHP {{ phpversion() }}
        </p>
    </div>

</body>
</html>

</html>


      
