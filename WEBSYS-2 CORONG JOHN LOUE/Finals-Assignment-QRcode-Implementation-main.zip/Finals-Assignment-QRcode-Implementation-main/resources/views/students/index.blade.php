@extends('layouts.app')

@section('content')

<style>
    body{
        background: linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    }

    .glass-card{
        background: rgba(255,255,255,0.08);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        color: white;
    }

    .table thead{
        background: linear-gradient(45deg,#00c6ff,#0072ff);
        color: white;
    }

    .table td, .table th{
        vertical-align: middle;
    }

    .btn-gradient{
        background: linear-gradient(45deg,#00c6ff,#0072ff);
        border: none;
        border-radius: 10px;
        color: white;
    }

    .btn-gradient:hover{
        opacity: 0.9;
    }

    .search-box{
        border-radius: 10px;
        overflow: hidden;
    }

    .badge-year{
        background: #00c6ff;
        color: #000;
        font-weight: 600;
    }
</style>

<div class="container py-4">

    {{-- HEADER --}}
    <div class="d-flex justify-content-between align-items-center mb-4 text-white">
        <h2 class="fw-bold">🎓 Students</h2>

        <a href="{{ route('students.create') }}" class="btn btn-gradient shadow">
            + Add Student
        </a>
    </div>

    {{-- SEARCH --}}
    <form method="GET" class="mb-4">
        <div class="input-group shadow search-box">
            <input type="text"
                   name="search"
                   value="{{ $search }}"
                   class="form-control"
                   placeholder="🔍 Search by name, course, year...">

            <button class="btn btn-dark">Search</button>
        </div>
    </form>

    {{-- TABLE --}}
    <div class="glass-card shadow p-3">

        <div class="table-responsive">
            <table class="table table-hover text-white">

                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Year</th>
                        <th>QR Code</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>

                <tbody>

                @forelse($students as $student)
                <tr>

                    <td class="fw-semibold">{{ $student->name }}</td>

                    <td>{{ $student->course }}</td>

                    <td>
                        <span class="badge badge-year">
                            {{ $student->year }}
                        </span>
                    </td>

                    <td>
                        <div class="bg-white p-2 rounded shadow-sm d-inline-block">
                            {!! $student->qr !!}
                        </div>
                    </td>

                    <td class="text-center">

                        <a href="{{ route('students.show', $student->id) }}"
                           class="btn btn-sm btn-info text-white mb-1">
                            👁 View
                        </a>

                        <a href="{{ route('students.edit', $student->id) }}"
                           class="btn btn-sm btn-warning mb-1">
                            ✏ Edit
                        </a>

                        <form action="{{ route('students.destroy', $student->id) }}"
                              method="POST"
                              class="d-inline">
                            @csrf
                            @method('DELETE')

                            <button class="btn btn-sm btn-danger"
                                    onclick="return confirm('Delete this student?')">
                                🗑 Delete
                            </button>
                        </form>

                    </td>

                </tr>

                @empty
                <tr>
                    <td colspan="5" class="text-center text-light py-4">
                        🚫 No students found
                    </td>
                </tr>
                @endforelse

                </tbody>

            </table>
        </div>

    </div>

</div>

@endsection