@extends('layouts.app')

@section('content')

<style>
    body{
        background: linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    }

    .form-container{
        max-width: 650px;
        margin: auto;
    }

    .glass-card{
        background: rgba(255,255,255,0.1);
        backdrop-filter: blur(12px);
        border-radius: 20px;
        color: white;
    }

    .form-control{
        border-radius: 10px;
        border: none;
    }

    .form-control:focus{
        box-shadow: 0 0 5px #00c6ff;
    }

    .btn-gradient{
        background: linear-gradient(45deg,#00c6ff,#0072ff);
        border: none;
        border-radius: 10px;
        font-weight: 600;
    }

    .btn-gradient:hover{
        opacity: 0.9;
    }
</style>

<div class="container py-5">

    <div class="form-container">

        <div class="d-flex justify-content-between align-items-center mb-4 text-white">
            <h2 class="fw-bold">🎓 Add Student</h2>

            <a href="{{ route('students.index') }}" class="btn btn-light">
                ← Back
            </a>
        </div>

        <div class="glass-card shadow p-4">

            {{-- SUCCESS --}}
            @if(session('success'))
                <div class="alert alert-success text-center">
                    {{ session('success') }}
                </div>
            @endif

            {{-- ERROR --}}
            @if($errors->any())
                <div class="alert alert-danger">
                    {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('students.store') }}">
                @csrf

                <div class="mb-3">
                    <label class="fw-semibold">Full Name</label>
                    <input name="name" class="form-control" placeholder="Enter student name">
                </div>

                <div class="mb-3">
                    <label class="fw-semibold">Course</label>
                    <input name="course" class="form-control" placeholder="BSIT / BSCS">
                </div>

                <div class="mb-3">
                    <label class="fw-semibold">Year Level</label>
                    <input name="year" class="form-control" placeholder="1st Year / 2nd Year">
                </div>

                <div class="mb-4">
                    <label class="fw-semibold">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="student@email.com">
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-gradient w-100 py-2">
                        💾 Save Student
                    </button>

                    <button type="reset" class="btn btn-outline-light w-100">
                        Reset
                    </button>
                </div>

            </form>

        </div>

    </div>

</div>

@endsection