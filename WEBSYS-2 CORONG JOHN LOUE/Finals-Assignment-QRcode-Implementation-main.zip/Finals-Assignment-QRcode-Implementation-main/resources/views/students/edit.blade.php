@extends('layouts.app')

@section('content')

<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="fw-bold">Edit Student</h2>

        <a href="{{ route('students.index') }}" class="btn btn-secondary shadow-sm">
            ← Back
        </a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-4">

            <form method="POST" action="{{ route('students.update', $student->id) }}">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label class="form-label fw-semibold">Full Name</label>
                    <input name="name"
                           value="{{ $student->name }}"
                           class="form-control"
                           placeholder="Enter student name"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Course</label>
                    <input name="course"
                           value="{{ $student->course }}"
                           class="form-control"
                           placeholder="e.g. BSIT, BSCS"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Year Level</label>
                    <input name="year"
                           value="{{ $student->year }}"
                           class="form-control"
                           placeholder="e.g. 1st Year, 2nd Year"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Email</label>
                    <input type="email"
                           name="email"
                           value="{{ $student->email }}"
                           class="form-control"
                           placeholder="student@email.com"
                           required>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-primary px-4 shadow-sm">
                        Update Student
                    </button>

                    <button type="reset" class="btn btn-outline-secondary">
                        Reset
                    </button>
                </div>

            </form>

        </div>
    </div>

</div>

@endsection
