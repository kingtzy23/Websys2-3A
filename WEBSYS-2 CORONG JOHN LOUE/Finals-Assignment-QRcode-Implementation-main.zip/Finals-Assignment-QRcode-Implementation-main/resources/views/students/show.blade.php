@extends('layouts.app')

@section('content')

<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="fw-bold">👤 Student Details</h2>

        <a href="{{ route('students.index') }}" class="btn btn-secondary shadow-sm">
            ← Back
        </a>
    </div>

    <div class="row justify-content-center">

        <div class="col-md-6">

            <div class="card shadow-sm border-0">

                <div class="card-body text-center p-4">

                    <h4 class="fw-bold mb-3">{{ $student->name }}</h4>

                    <span class="badge bg-primary mb-2">
                        {{ $student->course }}
                    </span>

                    <span class="badge bg-info text-dark mb-3">
                        Year {{ $student->year }}
                    </span>

                    <hr>

                    <p class="mb-1">
                        📧 <strong>Email:</strong> {{ $student->email }}
                    </p>

                    <hr class="my-4">

                    <h6 class="mb-3 fw-semibold">QR Code</h6>

                    <div class="d-flex justify-content-center mb-3">
                        <div class="p-3 bg-light rounded shadow-sm">
                            {!! $qr !!}
                        </div>
                    </div>

                    <small class="text-muted">
                        Scan this QR code to view student data
                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

@endsection
