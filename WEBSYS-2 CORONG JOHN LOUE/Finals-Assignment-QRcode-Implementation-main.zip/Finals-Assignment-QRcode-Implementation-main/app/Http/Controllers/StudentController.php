<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class StudentController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->search;

        $students = Student::when($search, function ($query, $search) {
            $query->where('name', 'like', "%$search%")
                  ->orWhere('course', 'like', "%$search%")
                  ->orWhere('year', 'like', "%$search%");
        })->get();

        foreach ($students as $student) {
            $student->qr = QrCode::size(100)->generate(
                route('students.show', $student->id)
            );
        }

        return view('students.index', compact('students', 'search'));
    }

    public function create()
    {
        return view('students.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'course' => 'required',
            'year' => 'required',
            'email' => 'required|email|unique:students'
        ]);

        Student::create($request->all());

        return redirect()->route('students.index')
            ->with('success', 'Student created.');
    }

    public function show(Student $student)
    {
        $qr = QrCode::size(200)->generate(json_encode([
            'id' => $student->id,
            'name' => $student->name,
            'course' => $student->course,
            'year' => $student->year,
            'email' => $student->email
        ]));

        return view('students.show', compact('student', 'qr'));
    }

    public function edit(Student $student)
    {
        return view('students.edit', compact('student'));
    }

    public function update(Request $request, Student $student)
    {
        $request->validate([
            'name' => 'required',
            'course' => 'required',
            'year' => 'required',
            'email' => 'required|email|unique:students,email,' . $student->id
        ]);

        $student->update($request->all());

        return redirect()->route('students.index')
            ->with('success', 'Student updated.');
    }

    public function destroy(Student $student)
    {
        $student->delete();

        return redirect()->route('students.index')
            ->with('success', 'Student deleted.');
    }
}