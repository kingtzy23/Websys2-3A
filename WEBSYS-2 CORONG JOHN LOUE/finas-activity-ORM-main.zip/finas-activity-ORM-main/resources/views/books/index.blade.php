<!DOCTYPE html>
<html>
<head>
    <title>Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#0f172a;
            font-family: 'Segoe UI', sans-serif;
            color:white;
        }

        .header{
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:30px;
        }

        .btn-add{
            background:#22c55e;
            border:none;
            border-radius:25px;
            padding:8px 18px;
        }

        .btn-add:hover{
            background:#16a34a;
        }

        .book-card{
            background:#1e293b;
            border-radius:15px;
            padding:20px;
            transition:0.3s;
        }

        .book-card:hover{
            transform:translateY(-5px);
            box-shadow:0 10px 20px rgba(0,0,0,0.5);
        }

        .book-title{
            font-size:18px;
            font-weight:600;
        }

        .book-author{
            font-size:14px;
            color:#94a3b8;
        }

        .book-date{
            font-size:12px;
            color:#64748b;
        }

        .actions{
            margin-top:15px;
        }

        .btn-warning{
            border-radius:20px;
        }

        .btn-danger{
            border-radius:20px;
        }
    </style>
</head>

<body>

<div class="container py-5">

    <!-- Header -->
    <div class="header">
        <h2>📚 My Books</h2>

        <a href="{{ route('books.create') }}" class="btn btn-add">
            + Add Book
        </a>
    </div>

    <!-- Cards -->
    <div class="row g-4">

        @foreach ($books as $book)
        <div class="col-md-4">
            <div class="book-card">

                <div class="book-title">
                    {{ $book->title }}
                </div>

                <div class="book-author">
                    {{ $book->author }}
                </div>

                <div class="book-date">
                    {{ $book->published_date }}
                </div>

                <div class="actions">
                    <a href="{{ route('books.edit',$book->id) }}" 
                       class="btn btn-warning btn-sm">
                       Edit
                    </a>

                    <form action="{{ route('books.destroy',$book->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger btn-sm">
                            Delete
                        </button>
                    </form>
                </div>

            </div>
        </div>
        @endforeach

    </div>

</div>
</body>
</html>