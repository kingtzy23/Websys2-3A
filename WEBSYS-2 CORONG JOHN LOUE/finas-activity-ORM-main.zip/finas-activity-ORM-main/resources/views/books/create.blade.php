<!DOCTYPE html>
<html>
<head>
    <title>Add Book</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg,#0f2027,#203a43,#2c5364);
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            font-family: 'Segoe UI', sans-serif;
        }

        .form-box{
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(15px);
            border-radius:20px;
            padding:40px;
            color:white;
            width:100%;
            max-width:500px;
        }

        .form-control{
            border-radius:10px;
        }

        .btn-custom{
            background: #00c6ff;
            border:none;
            border-radius:10px;
            font-weight:bold;
        }

        .btn-custom:hover{
            background:#0072ff;
        }

        .title-icon{
            font-size:30px;
        }
    </style>
</head>

<body>

<div class="form-box shadow-lg">

    <h2 class="text-center mb-4">
        <span class="title-icon">📚</span> Add New Book
    </h2>

    {{-- SUCCESS --}}
    @if(session('success'))
        <div class="alert alert-success text-center">
            {{ session('success') }}
        </div>
    @endif

    {{-- ERRORS --}}
    @if($errors->any())
        <div class="alert alert-danger">
            {{ $errors->first() }}
        </div>
    @endif

    <form action="{{ route('books.store') }}" method="POST">
        @csrf

        <label class="fw-bold">Title</label>
        <input type="text" name="title" class="form-control mb-3" placeholder="Enter book title">

        <label class="fw-bold">Author</label>
        <input type="text" name="author" class="form-control mb-3" placeholder="Enter author name">

        <label class="fw-bold">Published Date</label>
        <input type="date" name="published_date" class="form-control mb-4">

        <button class="btn btn-custom w-100 py-2">💾 Save Book</button>

        <a href="/books" class="btn btn-light w-100 mt-2">⬅ Back</a>
    </form>

</div>

</body>
</html>