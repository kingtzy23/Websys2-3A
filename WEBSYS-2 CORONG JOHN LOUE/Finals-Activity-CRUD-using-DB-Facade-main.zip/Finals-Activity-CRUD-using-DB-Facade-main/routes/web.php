<?php

use App\Http\Controllers\AuthController;

use Illuminate\Support\Facades\Route;

Route::get('/', fn()=>redirect()->route('login'));

Route::get('/register',[AuthController::class,'showRegister'])->name('register');
Route::post('/register',[AuthController::class,'register'])->name('register.post');

Route::get('/login',[AuthController::class,'showLogin'])->name('login');
Route::post('/login',[AuthController::class,'login'])->name('login.post');

Route::post('/logout',[AuthController::class,'logout'])->name('logout');

Route::get('/dashboard',[AuthController::class,'dashboard'])->name('dashboard');
Route::get('/settings',[AuthController::class,'settings'])->name('user.settings');
Route::post('/settings',[AuthController::class,'updateSettings'])->name('user.settings.update');

Route::get('/user/delete/{id}',[AuthController::class,'delete'])->name('user.delete');
Route::get('/user/edit/{id}',[AuthController::class,'edit'])->name('user.edit');
Route::post('/user/update/{id}',[AuthController::class,'update'])->name('user.update');
Route::match(['post', 'put'], '/user/update/{id}', [AuthController::class, 'update'])->name('user.update');

Route::get('/', function () { return view('welcome'); });