<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Session;   
use Illuminate\Support\Facades\Hash;      

class AuthController extends Controller
{
    // SHOW PAGES
    public function showRegister(){ return view('register'); }
    public function showLogin(){ return view('login'); }

    // REGISTER USER
    public function register(Request $request)
    {
        $request->validate([
            'email'=>'required|email|unique:users',
            'password'=>'required|min:4'
        ]);

        $user = User::create([
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'phone'=>$request->phone,
            'gender'=>$request->gender,
            'birthdate'=>$request->birthdate,
            'address'=>$request->address,
            'city'=>$request->city,
            'province'=>$request->province,
            'zipcode'=>$request->zipcode,
            'occupation'=>$request->occupation,
            'company'=>$request->company,
        ]);

        return redirect()->route('login')->with('success','Registered successfully');
    }

    // LOGIN
    public function login(Request $request)
    {
        $user = User::where('email',$request->email)->first();

        if(!$user || !Hash::check($request->password,$user->password)){
            return back()->withErrors(['Invalid login']);
        }

        // SESSION STORE
        Session::put('user_id',$user->id);
        Session::put('user_name',$user->name);
        Session::put('user_email',$user->email);

        return redirect()->route('dashboard');
    }

    // LOGOUT
    public function logout()
    {
        Session::flush();
        return redirect()->route('login');
    }

    // DASHBOARD (READ USERS)
    public function dashboard()
    {
        if(!Session::has('user_id')) return redirect()->route('login');

        $user = User::find(Session::get('user_id'));
        $users = User::all();

        return view('dashboard',compact('user','users'));
    }

    // SETTINGS PAGE
    public function settings()
    {
        $user = User::find(Session::get('user_id'));
        return view('settings',compact('user'));
    }

    public function updateSettings(Request $request)
    {
        $user = User::find(Session::get('user_id'));
        $user->update($request->all());
        return back()->with('success','Profile Updated');
    }

    // DELETE USER
    public function delete($id)
    {
        User::find($id)->delete();
        return back()->with('success','User Deleted');
    }

    // EDIT USER PAGE
    public function edit($id)
    {
        $user = User::find($id);
        return view('edit',compact('user'));
    }

    // UPDATE USER
    public function update(Request $request,$id)
    {
        $user = User::find($id);
        $user->update($request->all());
        return redirect()->route('dashboard')->with('success','User Updated');
    }
    
}