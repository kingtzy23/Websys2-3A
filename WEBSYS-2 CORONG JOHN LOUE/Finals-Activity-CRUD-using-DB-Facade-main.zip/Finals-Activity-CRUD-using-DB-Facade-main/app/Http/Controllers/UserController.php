<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User;

class UserController extends Controller
{
    // Show settings form
    public function settings()
    {
        $user = User::find(Session::get('user_id'));
        return view('user.settings', compact('user'));
    }

    // Handle settings update
    public function updateSettings(Request $request)
    {
        $request->validate([
            'name'  => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . Session::get('user_id'),
        ]);

        $user = User::find(Session::get('user_id'));
        $user->update([
            'name'  => $request->name,
            'email' => $request->email,
        ]);

        // Update session with new values
        Session::put('user_name',  $user->name);
        Session::put('user_email', $user->email);

        return back()->with('success', 'Profile updated successfully!');
    }
}