<form action="{{ route('logout') }}" method="POST" class="mt-2">
    @csrf
    <button type="submit" class="btn btn-danger w-100">
        🚪 Logout
    </button>
</form>