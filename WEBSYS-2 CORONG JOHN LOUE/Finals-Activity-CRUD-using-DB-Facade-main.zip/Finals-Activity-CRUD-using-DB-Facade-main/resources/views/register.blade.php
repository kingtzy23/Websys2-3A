@extends('layouts.app')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-8">

        <div class="card shadow-lg border-0">
            <div class="card-header bg-success text-white text-center">
                <h3 class="mb-0">Create Account</h3>
                <small>Join our Laravel CRUD System</small>
            </div>

            <div class="card-body p-4">

                {{-- SUCCESS MESSAGE --}}
                @if(session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif

                {{-- GLOBAL ERRORS --}}
                @if ($errors->any())
                    <div class="alert alert-danger">
                        Please fix the errors below.
                    </div>
                @endif

                <form action="{{ route('register.post') }}" method="POST">
                @csrf

                <!-- BASIC INFO -->
                <h5 class="mb-3 text-primary">Basic Information</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Full Name</label>
                        <input type="text" name="name" class="form-control"
                               value="{{ old('name') }}" required>
                        @error('name') <small class="text-danger">{{ $message }}</small> @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Email Address</label>
                        <input type="email" name="email" class="form-control"
                               value="{{ old('email') }}" required>
                        @error('email') <small class="text-danger">{{ $message }}</small> @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                        @error('password') <small class="text-danger">{{ $message }}</small> @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Phone Number</label>
                        <input type="text" name="phone" class="form-control"
                               value="{{ old('phone') }}" required>
                    </div>
                </div>

                <hr>

                <!-- PERSONAL INFO -->
                <h5 class="mb-3 text-primary">Personal Information</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Gender</label>
                        <select name="gender" class="form-control">
                            <option value="">Select Gender</option>
                            <option>Male</option>
                            <option>Female</option>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Birthdate</label>
                        <input type="date" name="birthdate" class="form-control">
                    </div>
                </div>

                <hr>

                <!-- ADDRESS -->
                <h5 class="mb-3 text-primary">Address</h5>

                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label>Address</label>
                        <input type="text" name="address" class="form-control" value="{{ old('address') }}">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>City</label>
                        <input type="text" name="city" class="form-control">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>Province</label>
                        <input type="text" name="province" class="form-control">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>Zip Code</label>
                        <input type="text" name="zipcode" class="form-control">
                    </div>
                </div>

                <hr>

                <!-- WORK INFO -->
                <h5 class="mb-3 text-primary">Work Information</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Occupation</label>
                        <input type="text" name="occupation" class="form-control">
                    </div>

                    <div class="col-md-6 mb-4">
                        <label>Company</label>
                        <input type="text" name="company" class="form-control">
                    </div>
                </div>

                <button type="submit" class="btn btn-success w-100 py-2">
                    Create Account
                </button>

                </form>

                <div class="text-center mt-3">
                    Already have an account?
                    <a href="{{ route('login') }}">Login here</a>
                </div>

            </div>
        </div>

    </div>
</div>

@endsection