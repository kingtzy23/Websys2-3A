@extends('layouts.app')

@section('content')
<div class="text-center">
    <h1>Welcome to Laravel Auth System 🎉</h1>
    <p class="mt-3">
        <a href="{{ route('login') }}" class="btn btn-primary">Login</a>
        <a href="{{ route('register') }}" class="btn btn-success">Register</a>
    </p>
</div>
@endsection