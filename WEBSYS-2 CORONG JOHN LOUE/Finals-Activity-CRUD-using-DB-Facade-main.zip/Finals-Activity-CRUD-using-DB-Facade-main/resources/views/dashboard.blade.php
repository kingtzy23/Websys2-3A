@extends('layouts.app')

@section('content')
<div class="container my-5">

    {{-- Success Alert --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> 
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    {{-- Logout Button --}}
    <div class="d-flex justify-content-end mb-3">
        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit" class="btn btn-danger">
                <i class="bi bi-box-arrow-right"></i> Logout
            </button>
        </form>
    </div>

    {{-- Users Card --}}
    <div class="card shadow-lg border-0 rounded-3">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-0">Registered Users</h4>
                <small class="text-white-50">Manage system users</small>
            </div>
            <span class="badge bg-light text-dark fs-6">
                Total: {{ count($users) }}
            </span>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Contact</th>
                            <th>City</th>
                            <th width="180">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($users as $u)
                            <tr>
                                <td>
                                    <span class="badge bg-secondary">#{{ $u->id }}</span>
                                </td>
                                <td>
                                    <strong>{{ $u->name }}</strong><br>
                                    <small class="text-muted">{{ $u->email }}</small>
                                </td>
                                <td>
                                    <i class="bi bi-telephone-fill text-success me-1"></i>
                                    {{ $u->phone ?? 'N/A' }}
                                </td>
                                <td>
                                    <span class="badge bg-info text-dark">
                                        {{ $u->city ?? 'N/A' }}
                                    </span>
                                </td>
                                <td>
                                    <a href="{{ route('user.edit',$u->id) }}" class="btn btn-sm btn-warning me-1">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </a>
                                    <a href="{{ route('user.delete',$u->id) }}" class="btn btn-sm btn-danger"
                                       onclick="return confirm('Delete this user?')">
                                        <i class="bi bi-trash-fill"></i> Delete
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted py-3">
                                    <i class="bi bi-exclamation-circle me-2"></i>No users found
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection