@extends('layouts.app')

@section('content')

<div class="row justify-content-center align-items-center" style="min-height:80vh">

    <div class="col-md-5">

        <div class="card shadow-lg border-0">
            
            <div class="card-header bg-dark text-white text-center">
                <h3 class="mb-0">Welcome Back 👋</h3>
                <small>Login to your account</small>
            </div>

            <div class="card-body p-4">

                @if($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show">
                        {{ $errors->first() }}
                        <button class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                <form action="{{ route('login.post') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label class="fw-bold">Email Address</label>
                        <input type="email" name="email" class="form-control form-control-lg" placeholder="Enter email" required>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold">Password</label>
                        <input type="password" name="password" class="form-control form-control-lg" placeholder="Enter password" required>
                    </div>

                    <button class="btn btn-primary w-100 btn-lg">
                        🔐 Login Account
                    </button>
                </form>

                <hr>

                <div class="text-center">
                    Don't have an account?
                    <a href="{{ route('register') }}" class="fw-bold text-decoration-none">
                        Create Account
                    </a>
                </div>

            </div>
        </div>

    </div>

</div>

@endsection