@extends('layouts.app')

@section('content')
<div class="col-md-6 offset-md-3">
    <h3 class="text-center mb-3">Edit User</h3>

    <form action="{{ route('user.update', $user->id) }}" method="POST">
        @csrf
        @method('PUT')

        <!-- Name -->
        <div class="mb-2">
            <label>Name</label>
            <input type="text" name="name" value="{{ $user->name }}" class="form-control" required>
        </div>

        <!-- Email -->
        <div class="mb-2">
            <label>Email</label>
            <input type="email" name="email" value="{{ $user->email }}" class="form-control" required>
        </div>

        <!-- Phone -->
        <div class="mb-2">
            <label>Phone</label>
            <input type="text" name="phone" value="{{ $user->phone }}" class="form-control">
        </div>

        <!-- Gender -->
        <div class="mb-2">
            <label>Gender</label>
            <select name="gender" class="form-control">
                <option value="Male" {{ $user->gender == 'Male' ? 'selected' : '' }}>Male</option>
                <option value="Female" {{ $user->gender == 'Female' ? 'selected' : '' }}>Female</option>
            </select>
        </div>

        <!-- Birthdate -->
        <div class="mb-2">
            <label>Birthdate</label>
            <input type="date" name="birthdate" value="{{ $user->birthdate }}" class="form-control">
        </div>

        <!-- Address -->
        <div class="mb-2">
            <label>Address</label>
            <input type="text" name="address" value="{{ $user->address }}" class="form-control">
        </div>

        <!-- City -->
        <div class="mb-2">
            <label>City</label>
            <input type="text" name="city" value="{{ $user->city }}" class="form-control">
        </div>

        <!-- Province -->
        <div class="mb-2">
            <label>Province</label>
            <input type="text" name="province" value="{{ $user->province }}" class="form-control">
        </div>

        <!-- Zipcode -->
        <div class="mb-2">
            <label>Zipcode</label>
            <input type="text" name="zipcode" value="{{ $user->zipcode }}" class="form-control">
        </div>

        <!-- Occupation -->
        <div class="mb-2">
            <label>Occupation</label>
            <input type="text" name="occupation" value="{{ $user->occupation }}" class="form-control">
        </div>

        <!-- Company -->
        <div class="mb-3">
            <label>Company</label>
            <input type="text" name="company" value="{{ $user->company }}" class="form-control">
        </div>

        <button type="submit" class="btn btn-success w-100">Update</button>
        <a href="{{ route('dashboard') }}" class="btn btn-secondary w-100 mt-2">Back</a>
    </form>
</div>
@endsection