@extends('layouts.app')

@section('content')

<div class="col-md-6 offset-md-3">

<div class="card">

<div class="card-header">User Settings</div>

<div class="card-body">

@if(session('success'))

<div class="alert alert-success">{{ session('success') }}</div>

@endif

<form action="{{ route('user.settings.update') }}" method="POST">

@csrf

<div class="mb-3">

<label>Full Name</label>

<input type="text" name="name" class="form-control"

value="{{ old('name', $user->name) }}">

</div>

#

<div class="mb-3">

<label>Email Address</label>

<input type="email" name="email"
class="form-control"

value="{{ old('email', $user->email)
}}">

</div>

<button type="submit" class="btn
btn-primary">Update Profile</button>

<a href="{{ route('dashboard') }}" class="btn
btn-secondary">Back</a>

</form>

</div>

</div>

</div>

@endsection