```html id="luxgal22"
<!DOCTYPE html>
<html>
<head>
    <title>Gallery</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg,#000000,#1a1a1a,#2b2b2b);
            min-height:100vh;
            color:#f5d27a;
            font-family: 'Segoe UI', sans-serif;
        }

        /* HEADER */
        .title{
            font-weight:700;
            color:#ffd700;
            letter-spacing:1px;
        }

        /* BUTTON */
        .btn-gold{
            background: linear-gradient(45deg,#d4af37,#ffd700);
            color:#000;
            border:none;
            border-radius:10px;
            font-weight:500;
        }

        .btn-gold:hover{
            opacity:0.9;
        }

        /* GALLERY BOX */
        .gallery-box{
            background:#111;
            border-radius:20px;
            padding:30px;
            color:#f5d27a;
            border:1px solid rgba(212,175,55,0.2);
        }

        /* CARD */
        .card{
            background:#0d0d0d;
            border:1px solid rgba(212,175,55,0.2);
            border-radius:15px;
            transition:0.3s;
        }

        .card:hover{
            transform: translateY(-5px) scale(1.02);
            box-shadow:0 10px 30px rgba(212,175,55,0.3);
            border-color:#ffd700;
        }

        /* IMAGE */
        img{
            height:220px;
            object-fit:cover;
            border-radius:12px;
            transition:0.3s;
        }

        img:hover{
            transform: scale(1.08);
        }

        /* DELETE BUTTON */
        .btn-danger{
            background:#8b0000;
            border:none;
            border-radius:10px;
        }

        /* PAGINATION */
        .pagination{
            justify-content:center;
        }

        .page-link{
            background:#0d0d0d;
            color:#d4af37;
            border:1px solid rgba(212,175,55,0.3);
            border-radius:8px !important;
            margin:0 3px;
        }

        .page-item.active .page-link{
            background:#d4af37;
            color:#000;
            border:none;
        }
    </style>
</head>

<body>

<div class="container py-5">

    <div class="text-center mb-4">
        <h1 class="title">🖼️ IMAGE GALLERY</h1>
        <a href="/upload" class="btn btn-gold shadow mt-3">Upload Images</a>
    </div>

    <div class="gallery-box shadow">

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <div class="row g-4">
            @foreach($photos as $photo)
            <div class="col-md-3 col-sm-6">
                <div class="card shadow-sm p-2">

                    <img src="{{ asset('images/'.$photo->image) }}" class="w-100">

                    <form action="{{ route('photos.destroy',$photo->id) }}" method="POST" class="mt-2">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger w-100">Delete</button>
                    </form>

                </div>
            </div>
            @endforeach
        </div>

        <div class="mt-4 text-center">
            {{ $photos->links() }}
        </div>

    </div>

</div>

</body>
</html>
```
