
<!DOCTYPE html>
<html>
<head>
    <title>Image Upload</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg,#000000,#1a1a1a,#2b2b2b);
            min-height:100vh;
            color:#f5d27a;
            font-family: 'Segoe UI', sans-serif;
        }

        /* GLASS PANEL */
        .glass{
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
            border-radius:20px;
            border:1px solid rgba(212,175,55,0.3);
        }

        .left-panel{
            padding:30px;
        }

        .right-panel{
            background:#111;
            border-radius:20px;
            padding:25px;
            color:#f5d27a;
            border:1px solid rgba(212,175,55,0.2);
        }

        /* CARDS */
        .card{
            background:#0d0d0d;
            border:1px solid rgba(212,175,55,0.2);
            border-radius:15px;
            transition: all 0.3s ease;
        }

        .card:hover{
            transform: translateY(-5px) scale(1.02);
            box-shadow:0 10px 30px rgba(212,175,55,0.3);
            border-color:#d4af37;
        }

        /* IMAGE */
        img{
            height:150px;
            object-fit:cover;
            border-radius:10px;
            transition:0.3s;
        }

        img:hover{
            transform: scale(1.08);
        }

        /* BUTTONS */
        .btn{
            border-radius:10px;
            font-weight:500;
        }

        .btn-primary{
            background: linear-gradient(45deg,#d4af37,#ffd700);
            color:#000;
            border:none;
        }

        .btn-dark{
            background:#1a1a1a;
            color:#d4af37;
            border:1px solid #d4af37;
        }

        .btn-danger{
            background:#8b0000;
            border:none;
        }

        /* UPLOAD BOX */
        .upload-box{
            border:2px dashed rgba(212,175,55,0.4);
            border-radius:10px;
            padding:15px;
            text-align:center;
            cursor:pointer;
            transition:0.3s;
        }

        .upload-box:hover{
            border-color:#ffd700;
            background:rgba(212,175,55,0.1);
        }

        /* TEXT */
        h2{
            color:#ffd700;
            font-weight:600;
        }

        label{
            color:#d4af37;
        }

        /* PAGINATION */
        .pagination{
            justify-content:center;
        }

        .page-link{
            background:#0d0d0d;
            color:#d4af37;
            border:1px solid rgba(212,175,55,0.3);
            border-radius:8px !important;
            margin:0 3px;
        }

        .page-item.active .page-link{
            background:#d4af37;
            color:#000;
            border:none;
        }
    </style>
</head>

<body>

<div class="container-fluid py-5">
<div class="row g-4">

    <!-- LEFT SIDE -->
    <div class="col-md-4">
        <div class="glass left-panel shadow">

            <h2 class="mb-4 text-center">📤 Upload Images</h2>

            <!-- Single Upload -->
            <div class="card p-3 mb-4">
                <form action="{{ route('photos.store.single') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <label class="fw-bold">Single Image</label>

                    <div class="upload-box">
                        <input type="file" name="image" class="form-control border-0" required>
                        <small>Click or drag file</small>
                    </div>

                    <button class="btn btn-primary w-100 mt-2">Upload</button>
                </form>
            </div>

            <!-- Multiple Upload -->
            <div class="card p-3">
                <form action="{{ route('photos.store.multiple') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <label class="fw-bold">Multiple Images</label>

                    <div class="upload-box">
                        <input type="file" name="images[]" multiple class="form-control border-0" required>
                        <small>Select multiple files</small>
                    </div>

                    <button class="btn btn-dark w-100 mt-2">Upload Multiple</button>
                </form>
            </div>

            @if(session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

        </div>
    </div>

    <!-- RIGHT SIDE -->
    <div class="col-md-8">
        <div class="right-panel shadow">

            <h2 class="mb-4 text-center">🖼️ Gallery</h2>

            <div class="row g-3">
                @foreach($photos as $photo)
                <div class="col-md-4">
                    <div class="card p-2 shadow-sm">

                        <img src="{{ asset('images/'.$photo->image) }}" class="w-100">

                        <form action="{{ route('photos.destroy',$photo->id) }}" method="POST" class="mt-2">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger w-100 btn-sm">Delete</button>
                        </form>

                    </div>
                </div>
                @endforeach
            </div>

            <div class="mt-4">
                {{ $photos->links() }}
            </div>

        </div>
    </div>

</div>
</div>

</body>
</html>
```
