<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Photo;

class PhotoController extends Controller
{
  
    public function index()
    {
        $photos = Photo::latest()->paginate(6);
        return view('upload', compact('photos'));
    }


    public function storeSingle(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        $image = $request->file('image');
        $name = time().'_'.$image->getClientOriginalName();
        $image->move(public_path('images'), $name);

        Photo::create(['image' => $name]);

        return back()->with('success', 'Single image uploaded!');
    }

  
    public function storeMultiple(Request $request)
    {
        $request->validate([
            'images.*' => 'required|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        foreach ($request->file('images') as $image) {
            $name = time().'_'.$image->getClientOriginalName();
            $image->move(public_path('images'), $name);
            Photo::create(['image' => $name]);
        }

        return back()->with('success', 'Multiple images uploaded!');
    }

  
    public function destroy($id)
    {
        $photo = Photo::findOrFail($id);
        unlink(public_path('images/'.$photo->image));
        $photo->delete();

        return back()->with('success', 'Photo deleted!');
    }
}